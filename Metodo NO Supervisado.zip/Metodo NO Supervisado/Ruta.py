import pandas as pd
from sklearn.cluster import KMeans
from sklearn.metrics import pairwise_distances_argmin_min

# Cargar el conjunto de datos desde el archivo CSV
df = pd.read_csv('Rutas.csv')

# Mostrar el conjunto de datos para verificar la estructura
print(df.head())

# Preparar los datos para el modelo de aprendizaje no supervisado
X = df[['distancia']].values  # Usaremos solo la columna de distancia como característica

# Entrenar el modelo de K-Means para agrupar las rutas
num_clusters = 5  # Número de clústeres a generar
kmeans = KMeans(n_clusters=num_clusters)
kmeans.fit(X)

# Obtener las rutas representativas de cada clúster
representative_routes = []
for cluster_center in kmeans.cluster_centers_:
    # Encontrar el punto más cercano al centro del clúster (ruta representativa)
    closest_idx = pairwise_distances_argmin_min(cluster_center.reshape(1, -1), X)[0][0]
    representative_routes.append(df.iloc[closest_idx])

# Mostrar las rutas representativas encontradas
print("\nRutas representativas:")
for route in representative_routes:
    print(route[['inicio', 'final', 'distancia']])

# Función para encontrar la ruta más corta entre dos paradas
def encontrar_ruta_mas_corta(inicio, final):
    # Simular búsqueda del clúster que contiene la ruta más corta
    cluster_simulado = kmeans.predict([[0]])[0]  # Simplemente elegimos un valor para simular
    
    # Simular búsqueda de la ruta representativa dentro del clúster
    ruta_simulada = representative_routes[cluster_simulado]
    
    return ruta_simulada[['inicio', 'final', 'distancia']]

# Ejemplo de búsqueda de ruta más corta entre dos paradas
parada_inicio = 'Virgenpoblado'
parada_final = 'SalidaMontana '
ruta_mas_corta = encontrar_ruta_mas_corta(parada_inicio, parada_final)
print(f"\nLa ruta más corta entre {parada_inicio} y {parada_final} es:")
print(ruta_mas_corta)