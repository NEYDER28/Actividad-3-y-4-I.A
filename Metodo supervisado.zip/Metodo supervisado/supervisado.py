import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import OneHotEncoder

# Cargar el conjunto de datos
data = pd.read_csv('Datos.csv')

# Dividir los datos en características (X) y etiquetas (y)
X = data[['Origen', 'Destino']]
y = data['Distancia']

# Codificar las paradas como variables dummy
encoder = OneHotEncoder(handle_unknown='ignore')
X_encoded = encoder.fit_transform(X)

# Dividir los datos en entrenamiento y prueba
X_train, X_test, y_train, y_test = train_test_split(X_encoded, y, test_size=0.2, random_state=42)

# Entrenar el modelo de regresión lineal
model = LinearRegression()
model.fit(X_train, y_train)

# Calcular la distancia estimada para una nueva ruta
nueva_ruta = pd.DataFrame({'Origen': ['Virgenpoblado'], 'Destino': ['SalidaMontana']})
nueva_ruta_encoded = encoder.transform(nueva_ruta)
Recorrido = model.predict(nueva_ruta_encoded)

print('Distancia para la nueva ruta:', Recorrido[0])
